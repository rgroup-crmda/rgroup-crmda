##Figure 11.5, Table 11.10: MIMIC Model 
#########################################

library(lavaan)

##Read in data and prep
ex11.5dat <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-mimic-mplus.dat")
mySDs <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-mimic-mplus.dat", skip=0, nlines=1)
mycors <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-mimic-mplus.dat", skip=1, nlines=6)
myvarcov <- getCov(mycors, sds=mySDs, lower=TRUE, diagonal=TRUE, names=c("problems", "intimacy", "father", "mother", "fa_mo", "spouse"))

nObs <- 206

#################################
##Fit model 
#################################
modex11.5 <- 'FOE =~ 1*father + .859*mother + .932*fa_mo
			  Marital =~ 1*problems + .917*intimacy
			  FOE + Marital ~ spouse
			  father ~~ 39.421*father
			  mother ~~ 78.371*mother
			  fa_mo ~~ 94.994*fa_mo
			  problems ~~ 510.314*problems
			  intimacy ~~ 16.758*intimacy'
fitmodex11.5 <- cfa(modex11.5, sample.cov=myvarcov, sample.nobs=nObs, std.lv=FALSE)
summary(fitmodex11.5, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)

