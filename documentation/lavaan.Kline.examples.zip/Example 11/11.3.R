##Table 11.3 Figure 11.3

library(lavaan)
##data preparation 

ex11.3dat <- scan('http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat')
mymeans <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=0, nlines=1)
mySDs <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=1, nlines=1)
mycors <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=2, nlines=6)
myvarcov <- getCov(mycors, sds=mySDs, lower=TRUE, diagonal=TRUE, names=c("year1", "year2", "year3", "year4", "gender", "famstat"))


nObs <- 321

###########################################
##Fit Predict Model: 
##########################################
modex11.3  <- 'Initial =~ 1*year1 + 1*year2 + 1*year3 + 1*year4
			   Linear =~ 0*year1 + 1*year2 + 2*year3 + 3*year4
			   Initial ~ famstat + gender + 1
			   Linear ~ famstat + gender + 1
			   famstat ~ 1
			   gender ~ 1
			   year1 ~ 0
			   year2 ~ 0
			   year3 ~ 0
			   year4 ~ 0 
			   gender ~~ famstat
			   '

fitmodex11.3 <- growth(modex11.3, sample.cov=myvarcov, sample.mean=mymeans, sample.nobs=nObs, fixed.x=FALSE)
summary(fitmodex11.3, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)