##Figure 11.4, Table 9.8: Structured Means in Measurement Model

library(lavaan)

#Read in data and prep

ex11.4dat <-scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat")
g1means <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat", skip=0, nlines=1)
g1sds <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat", skip=1, nlines=1)
g1cors <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat", skip=2, nlines=5)

g2means <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat" , skip=7, nlines=1)
g2sds <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat", skip=8, nlines=1)
g2cors <- scan("http://www.guilford.com/add/kline/chapter11/mplus/sabatelli-means-mplus.dat", skip=9, nlines=5)

#push into correlation matrix, lower triangle
xindex <- c(0, 1, 3, 6, 10)
g1myvarcov <- outer(1:5, 1:5, FUN = function(X, Y) ifelse(Y <= X, g1cors[Y + xindex[X]], 0))
g2myvarcov <- outer(1:5, 1:5, FUN = function(X, Y) ifelse(Y <= X, g2cors[Y + xindex[X]], 0))


mynames <- c("problems", "intimacy", "father", "mother", "fa_mo")
colnames(g1myvarcov) <- mynames
rownames(g1myvarcov) <- mynames
colnames(g2myvarcov) <- mynames
rownames(g2myvarcov) <- mynames

##Create covariance matrices
mycov <- list()

g1varcov <- outer(g1sds, g1sds, FUN="*")
mycov[["g1"]] <- g1myvarcov*g1varcov

g2varcov <- outer(g2sds, g2sds, FUN="*")
mycov[["g2"]] <- g2myvarcov * g2varcov

mymeans <- list()
mymeans[["g1"]] <- g1means
mymeans[["g2"]] <- g2means

nObs <- list()
nObs[["g1"]] <- 103
nObs[["g2"]] <- 103

########################################
##start(value)* = starting value same as var*value in mplus
##Fit model:
############################

ex11.4mod <- 'Marital =~ 1*problems + start(.933)*intimacy
			  FOE =~ 1*father + start(.885)*mother + start(.897)*fa_mo
			  father ~~ mother
			  FOE ~~ Marital
			  father ~ 1
			  mother ~ 1
			  problems ~ 1 
			  intimacy ~ 1
			  fa_mo ~ 1
			  Marital ~ c(0, NA)*1 
			  FOE ~ c(0, NA)*1'


fitex11.4mod <- cfa(ex11.4mod, sample.cov=mycov, sample.mean=mymeans, sample.nobs=nObs, std.lv=FALSE, group.equal=c("intercepts", "loadings", "residuals"))
summary(fitex11.4mod, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)





