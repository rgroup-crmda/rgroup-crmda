##Figure 11.2, Table 11.2

library(lavaan)

##data preparation 

ex11.2dat <- scan('http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat')
mymeans <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=0, nlines=1)
mySDs <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=1, nlines=1)
mycors <- scan("http://www.guilford.com/add/kline/chapter11/mplus/duncan-mplus.dat", skip=2, nlines=6)
myvarcov <- getCov(mycors, sds=mySDs, lower=TRUE, diagonal=TRUE, names=c("year1", "year2", "year3", "year4", "gender", "famstat"))


nObs <- 321
#######################################################
##Fit Latent Growth Curve: Basis Model 
#####################################################
modex11.2  <- 'Initial =~ 1*year1 + 1*year2 + 1*year3 + 1*year4
			   Linear =~ 0*year1 + 1*year2 + 2*year3 + 3*year4
			   Initial ~ 1 
			   Linear ~ 1
			   year1 ~ 0
			   year2 ~ 0
			   year3 ~ 0
			   year4 ~ 0 '

fitmodex11.2 <- growth(modex11.2, sample.cov=myvarcov, sample.mean=mymeans, sample.nobs=nObs)
summary(fitmodex11.2, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)