# 4-Factor CFA. Figure 10.2 CFA, Table 10.1

library(lavaan)

#read in data and prep

ex10.2dat <-scan('http://www.guilford.com/add/kline/chapter10/mplus/houghton-mplus.dat')
mySDs <- ex10.2dat[1:12]
mycors <- lower2full(ex10.2dat[13:length(ex10.2dat)])

myvarcov <- cor2cov(mycors, mySDs)

mynames <- c("work1", "work2", "work3", "happy", "mood1", "mood2", "perform1", "perform2", "approval", "beliefs", "selftalk", "imagery")
colnames(myvarcov) <- mynames
rownames(myvarcov) <- mynames

nObs <- 263

#Specify Model 

ex10.2mod <- 'Construc =~ beliefs + selftalk + imagery
			  Dysfunc =~ perform1 + perform2 + approval
			  WellBe =~ happy + mood1 + mood2
			  JobSat =~ work1 + work2 + work3
			  happy ~~ mood2'
			  
#Fit model 
fitex10.2mod <- cfa(ex10.2mod, sample.cov=myvarcov, meanstructure=FALSE, sample.nobs=nObs, fixed.x=TRUE, std.lv=FALSE)
summary(fitex10.2mod, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE) 
