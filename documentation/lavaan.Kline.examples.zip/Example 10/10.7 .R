#FIGURE 10.7, TABLE 10.6

mySDs <- c(13.00, 13.50, 13.10, 12.50, 13.50, 14.20, 9.50, 11.10, 8.70)
lower <-
'1.00                                                                           
.42 1.00                                                                      
-.43 -.50 1.00                                                                 
-.39 -.43  .78 1.00                                                            
-.24 -.37  .69  .73 1.00                                                       
-.31 -.33  .63  .87  .72 1.00                                                  
-.25 -.25  .49  .53  .60  .59 1.00                                             
-.25 -.26  .42  .42  .44  .45  .77 1.00                                        
-.16 -.18  .23  .36  .38  .38  .59  .58  1.00  '

 myvarcov <- getCov(lower, sds=mySDs, lower=TRUE, diagonal=TRUE, names=c("parpsyV1", "lowsesV2",  "verbaliqV3", "readV4", "mathV5", "spellV6", "motivV7", "harmonyV8", "stableV9"))

##Sample size
nObs <- 158


##Specify and Fit model : 10.7

ex10.7mod <- 'RiskF1 =~ parpsyV1 + lowsesV2 + verbaliqV3 
			  AchieveF2 =~ readV4 + mathV5 + spellV6
			  ClassAdjF3 =~ motivV7 + harmonyV8 + stableV9
			  RiskF1 ~ AchieveF2 + ClassAdjF3
			 '


fitex10.7 <- sem(ex10.7mod, sample.cov=myvarcov, sample.nobs=nObs, std.lv=FALSE)
summary(fitex10.7, fit.measures=TRUE, standardized=TRUE)
   
