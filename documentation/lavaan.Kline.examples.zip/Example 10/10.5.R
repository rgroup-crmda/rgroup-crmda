## Figure 10.5, Table 10.5

library(lavaan)

#Read in data and prep

mySDs <- c(3.119, 3.279, 2.408, 3.270, 3.440, 2.961, 3.604, 3.194)
lower <-
' 1.00
 .44 1.00
 .69 .54 1.00
 .37 .08  .24 1.00
 .23 .05  .26  .29 1.00
 .12 .08  .08  .08 -.03 1.00
 .09 .06  .04  .01 -.02  .38 1.00
 .03 .02 -.02 -.07 -.11  .37 .46 1.00
'
 myvarcov <- getCov(lower, sds=mySDs, lower=TRUE, diagonal=TRUE, names=c("acculscl", "genstat",  "perlife", "educ", "income", "interper", "job", "depscale"))

##Sample size
nObs <- 983

##Specify and Fit model : 10.5

ex10.5mod <- 'Accultur =~ acculscl + genstat + perlife
			  SES =~ educ + income
			  Stress =~ interper + job 
			  Depression =~ depscale
			  Stress ~ Accultur
		      Depression ~ SES + Stress
   depscale ~~ 3.06*depscale 
   genstat ~~ perlife
   Accultur ~~ SES'

fitex10.5 <- sem(ex10.5mod, sample.cov=myvarcov, sample.nobs=nObs, std.lv=FALSE)
summary(fitex10.5, fit.measures=TRUE, standardized=TRUE)
   
   
 