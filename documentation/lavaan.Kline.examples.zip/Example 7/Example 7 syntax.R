## Recursive Path Model: Figure 7.1, Table 7.1

library(lavaan)

## Read in data and prep

ex7dat <-scan('http://www.guilford.com/add/kline/chapter7/mplus/sava-mplus.dat')
mySDs <- ex7dat[1:6]
mycors <- lower2full(ex7dat[7:length(ex7dat)])

myvarcov <- cor2cov(mycors, mySDs)

mynames <- c("coercive", "burnout", "support", "TPI", "experience", "somatic")
colnames(myvarcov) <- mynames
rownames(myvarcov) <- mynames

nObs <- 109


##Fit Model 
mod1ex7 <- 'burnout ~ coercive + support
		   TPI ~ coercive + support + burnout
		   experience + somatic ~ TPI
coercive~~support
experience~~0*somatic'


fit1 <- sem(mod1ex7, sample.cov = myvarcov, sample.nobs=nObs)

summary(fit1, fit.measures=TRUE, standardized=TRUE, rsquare=TRUE)

