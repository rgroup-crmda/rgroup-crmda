##Figure 8.1, Table 3.4

library(lavaan)

#Read in data and prep:

ex8dat <-scan('http://www.guilford.com/add/kline/chapter8/mplus/roth-mplus.dat')
mySDs <- ex8dat[1:5]
mycors <- lower2full(ex8dat[6:length(ex8dat)])

myvarcov <- cor2cov(mycors, mySDs)

mynames <- c("exercise", "hardy", "fitness", "stress", "illness")
colnames(myvarcov) <- mynames
rownames(myvarcov) <- mynames

nObs <- 373

##Fit Model 

mod1ex8 <- 'fitness ~ exercise
			stress ~ hardy
			illness ~ fitness + stress
exercise ~~ hardy'


fit1 <- sem(mod1ex8, sample.cov = myvarcov, sample.nobs=nObs, fixed.x=FALSE)

summary(fit1, fit.measures=TRUE, standardized=TRUE, rsquare=TRUE)
