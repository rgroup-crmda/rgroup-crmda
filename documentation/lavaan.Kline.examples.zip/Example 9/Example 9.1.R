#Figure 9.1, Table 9.1 Two Factor Model 

library(lavaan)

##read in data and data  preparation

ex9dat <-scan('http://www.guilford.com/add/kline/chapter9/mplus/kabc-cfa-mplus.dat')
mySDs <- ex9dat[1:8]
mycors <- lower2full(ex9dat[9:length(ex9dat)])
myvarcov <- cor2cov(mycors, mySDs)

mynames <- c("handmov", "numbrec", "wordord", "gesclos", "triangle", "spatmem", "matanalg", "photser")
colnames(myvarcov) <- mynames
rownames(myvarcov) <- mynames

nObs <- 200


#Specify Model

mod1ex9 <- 'Sequent =~ handmov + numbrec + wordord
			Simult =~ gesclos + triangle + spatmem + matanalg + photser
Sequent ~~ Simult'

#Fit Model
fit1 <- cfa(mod1ex9, sample.nobs=nObs, sample.cov=myvarcov)

summary(fit1, fit.measures=TRUE, standardized=TRUE, rsquare = TRUE, modindices=TRUE)
