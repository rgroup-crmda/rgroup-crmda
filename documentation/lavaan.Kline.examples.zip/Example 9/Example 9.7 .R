#Figure 9.7, Table 9.8

library(lavaan)

#Read in data and prep

ex9.7dat <-scan('http://www.guilford.com/add/kline/chapter9/mplus/sabatelli-mplus.dat')
g1sds <- scan("http://www.guilford.com/add/kline/chapter9/mplus/sabatelli-mplus.dat", skip=0, nlines=1)
g1cors <- scan("http://www.guilford.com/add/kline/chapter9/mplus/sabatelli-mplus.dat", skip=1, nlines=5)
g2sds <- scan("http://www.guilford.com/add/kline/chapter9/mplus/sabatelli-mplus.dat", skip=6, nlines=1)
g2cors <- scan("http://www.guilford.com/add/kline/chapter9/mplus/sabatelli-mplus.dat", skip=7,nlines=6)

#push into correlation matrix, lower triangle
xindex <- c(0, 1, 3, 6, 10)
g1myvarcov <- outer(1:5, 1:5, FUN = function(X, Y) ifelse(Y <= X, g1cors[Y + xindex[X]], 0))
g2myvarcov <- outer(1:5, 1:5, FUN = function(X, Y) ifelse(Y <= X, g2cors[Y + xindex[X]], 0))


mynames <- c("problems", "intimacy", "father", "mother", "fa_mo")
colnames(g1myvarcov) <- mynames
rownames(g1myvarcov) <- mynames
colnames(g2myvarcov) <- mynames
rownames(g2myvarcov) <- mynames

##Create covariance matrices
mycov <- list()

g1varcov <- outer(g1sds, g1sds, FUN="*")
mycov[["g1"]] <- g1myvarcov*g1varcov

g2varcov <- outer(g2sds, g2sds, FUN="*")
mycov[["g2"]] <- g2myvarcov * g2varcov

nObs <- list()
nObs[["g1"]] <- 103
nObs[["g2"]] <- 103
###########################################
#Fit model : Figure 9.7 but with error correlation, Table 9.8

mod1ex9.7 <- 'Marital =~ problems + intimacy
			  FOE =~ father + mother + fa_mo
			  father ~~ mother'
			  
fitboth9.7 <- cfa(mod1ex9.7, sample.cov=mycov, meanstructure=FALSE, sample.nobs=nObs, fixed.x=TRUE, std.lv=FALSE, group.equal=c("loadings", "residuals"))
summary(fitboth9.7, standardized=TRUE, fit.measures=TRUE, rsquare=TRUE)


